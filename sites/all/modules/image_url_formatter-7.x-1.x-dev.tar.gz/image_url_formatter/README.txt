This module add a url formatter for image field. 
Then you can output image url directly.

Most of the code, maybe more 90%, is just copy from the drupal core.
I think it is stable enough.

Usage
(1)After install this module,then you add an image field,
then you can goto this bundle's manage display page,here at format column,
you can choose "Image URL" instead of "Image".

(2)When you add an iamge field in your views,
then you config the Formatter for this field,
 here you can choose "Image URL" instead of "Image".

Then you can output image's URL instead of Image itself.